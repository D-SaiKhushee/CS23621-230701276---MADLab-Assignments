package com.example.bmicalc

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var weightInput: EditText
    private lateinit var heightInput: EditText
    private lateinit var calculateBtn: Button
    private lateinit var resultText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        weightInput = findViewById(R.id.etWeight)
        heightInput = findViewById(R.id.etHeight)
        calculateBtn = findViewById(R.id.btnCalculate)
        resultText = findViewById(R.id.tvResult)

        calculateBtn.setOnClickListener {
            calculateBMI()
        }
    }

    private fun calculateBMI() {

        val weightStr = weightInput.text.toString()
        val heightStr = heightInput.text.toString()

        if (weightStr.isEmpty() || heightStr.isEmpty()) {
            Toast.makeText(this, "Please enter weight and height", Toast.LENGTH_SHORT).show()
            return
        }

        val weight = weightStr.toDouble()
        val height = heightStr.toDouble()

        val bmi = weight / (height * height)

        val formattedBMI = String.format("%.2f", bmi)

        resultText.text = "Your BMI is: $formattedBMI"
    }
}