package com.example.panandpincode

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var panField: EditText
    private lateinit var pinField: EditText
    private lateinit var submitBtn: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        panField = findViewById(R.id.etPan)
        pinField = findViewById(R.id.etPincode)
        submitBtn = findViewById(R.id.btnValidate)

        submitBtn.setOnClickListener {
            processValidation()
        }
    }

    private fun processValidation() {

        val panValue = panField.text.toString().trim()
        val pinValue = pinField.text.toString().trim()

        when {
            panValue.isBlank() || pinValue.isBlank() -> {
                showMessage("Fields cannot be left blank")
            }

            !isValidPan(panValue) -> {
                panField.error = "Enter valid 10-digit alphanumeric PAN"
                panField.requestFocus()
            }

            !isValidPincode(pinValue) -> {
                pinField.error = "Enter valid 6-digit numeric Pincode"
                pinField.requestFocus()
            }

            else -> {
                showMessage("Details Verified Successfully")
            }
        }
    }

    private fun isValidPan(pan: String): Boolean {
        val panRegex = "^[A-Za-z0-9]{10}$".toRegex()
        return pan.matches(panRegex)
    }

    private fun isValidPincode(pin: String): Boolean {
        val pinRegex = Regex("^\\d{6}$")
        return pin.matches(pinRegex)
    }

    private fun showMessage(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }
}