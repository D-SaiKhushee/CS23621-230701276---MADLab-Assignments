package com.example.rec_digitalcafeloginvalidation
import android.os.Bundle
import android.util.Patterns
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var etEmail: EditText
    private lateinit var etPassword: EditText
    private lateinit var btnValidate: Button

    // Password pattern:
    // At least 1 uppercase, 1 digit, 1 special character, minimum 12 characters
    private val PASSWORD_PATTERN =
        Regex("^(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#\$%^&*()_+=|<>?{}\\[\\]~-]).{12,}\$")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        etEmail = findViewById(R.id.etEmail)
        etPassword = findViewById(R.id.etPassword)
        btnValidate = findViewById(R.id.btnValidate)

        btnValidate.setOnClickListener {
            validateFields()
        }
    }

    private fun validateFields() {

        val email = etEmail.text.toString().trim()
        val password = etPassword.text.toString().trim()

        // i) Check empty fields
        if (email.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Fields cannot be empty", Toast.LENGTH_SHORT).show()
            return
        }

        // ii) Validate proper college email ID
        if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()
            || !email.endsWith("@rajalakshmi.edu.in")) {

            Toast.makeText(this, "Enter valid college email ID", Toast.LENGTH_SHORT).show()
            return
        }

        // iii) Validate password
        if (!PASSWORD_PATTERN.matches(password)) {
            Toast.makeText(
                this,
                "Password must contain 1 uppercase, 1 number, 1 special symbol and minimum 12 characters",
                Toast.LENGTH_LONG
            ).show()
            return
        }

        Toast.makeText(this, "Validation Successful!", Toast.LENGTH_SHORT).show()
    }
}